CREATE DATABASE BDAula01;
use BDAula01;

CREATE TABLE pessoa(
     id int AUTO_INCREMENT PRIMARY KEY,
     nome varchar(50) NOT NULL,
     sexo varchar(1) NOT NULL,
     idioma varchar(10) NOT NULL
     );

INSERT INtO pessoa (nome,sexo, idioma)
     values
     ("Gerald", "M", "Inglês"),
     ("William", "M", "Inglês"),
     ("Umberto", "M", "Espanhol"),
     ("Jostein", "M", "Alemão"),
     ("Stephen", "M", "Holandês");

SELECT * FROM pessoa;

CREATE TABLE veiculo(
     id int AUTO_INCREMENT PRIMARY KEY,
     modelo VARCHAR(30),
     placa varchar(7),
     id_pessoa int NOT null,
     foreign key(id_pessoa) references pessoa(id)
     );