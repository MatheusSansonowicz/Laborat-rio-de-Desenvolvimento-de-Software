/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package beans;

/**
 *
 * @author laboratorio
 */
public class Veiculo {
    private int id;
    private String modelo;
    private String placa;
    private Pessoa pessoaID;

    public Veiculo(String modelo, String placa, Pessoa pessoaID) {
        this.modelo = modelo;
        this.placa = placa;
        this.pessoaID = pessoaID;
    }

    public Veiculo() {
    }

    public int getId() {
        return id;
    }

    public String getModelo() {
        return modelo;
    }

    public String getPlaca() {
        return placa;
    }

    public Pessoa getPessoaID() {
        return pessoaID;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public void setPlaca(String placa) {
        this.placa = placa;
    }

    public void setPessoaID(Pessoa pessoaID) {
        this.pessoaID = pessoaID;
    }
    
    
}

